# MultiTask Earn – Android WebView App

Kotlin + WebView app that opens the existing website https://multitaskearn.free.nf inside the app.
It uses the website's real backend. No fake login, demo data, or ads are included.

- Min Android 8.0 (API 26), target API 34
- Permissions: INTERNET, ACCESS_NETWORK_STATE (and WRITE_EXTERNAL_STORAGE only on Android 9 and below, for downloads)
- Splash screen, app icon, loading bar, pull-to-refresh, offline error screen with Retry
- Back button goes to the previous web page; exit confirmation when no page is left
- External links open in the browser; only HTTPS links of the website stay inside the app
- SSL errors are never ignored

## Build APK
GitHub Actions: see `docs/URDU_GUIDE.md` (Urdu). Workflows are in `.github/workflows/`.
Website address is set in `app/src/main/java/com/multitaskearn/app/MainActivity.kt` (`HOME_URL`).

## Docs (Urdu)
- docs/URDU_GUIDE.md – setup, GitHub upload, APK build and install
- docs/SIGNING_GUIDE_UR.md – release signing with GitHub Secrets
- docs/TESTING_GUIDE_UR.md – testing checklist

## Note about Gradle Wrapper
`gradle-wrapper.jar` is not included (it could not be downloaded in the build environment).
GitHub Actions installs Gradle 8.7 itself, so no wrapper is needed. In Android Studio, open the project and, if asked, let it use Gradle 8.7.
