# MultiTask Earn – مکمل اردو گائیڈ

یہ پروجیکٹ آپ کی ویب سائٹ https://multitaskearn.free.nf کو Android ایپ کے اندر کھولتا ہے۔ ویب سائٹ کا اصل Backend، لاگ اِن اور ڈیٹا ہی استعمال ہوتا ہے۔

## مرحلہ 1: ZIP کھولیں (Extract)
GitHub ZIP فائل کو خود نہیں کھولتا، اس لیے پہلے ZIP کو اپنے کمپیوٹر پر Extract کریں۔ اندر یہ چیزیں نظر آئیں گی: `app`، `gradle`، `.github`، `build.gradle.kts`، `settings.gradle.kts` وغیرہ۔

## مرحلہ 2: GitHub پر Repository بنائیں
1. github.com پر لاگ اِن کریں (اکاؤنٹ نہیں ہے تو بنائیں)۔
2. اوپر دائیں طرف **+** دبائیں، پھر **New repository**۔
3. نام لکھیں: `multitask-earn-app`
4. **Private** منتخب کریں (بہتر ہے)۔
5. **Create repository** دبائیں۔

## مرحلہ 3: فائلیں اپلوڈ کریں
1. نئی Repository میں **uploading an existing file** کے لنک پر کلک کریں۔
2. Extract کیے ہوئے فولڈر کے **اندر** کی تمام فائلیں اور فولڈرز ڈریگ کرکے ڈال دیں (فولڈر کے اندر کی چیزیں، باہر کا فولڈر نہیں)۔
3. نیچے **Commit changes** دبائیں۔

**اہم:** `.github` فولڈر چھپا ہوا ہو سکتا ہے۔
- Windows: File Explorer میں View → Show → Hidden items۔
- Mac: Finder میں Cmd + Shift + . دبائیں۔

اگر `.github` اپلوڈ نہ ہو تو GitHub میں **Add file → Create new file** دبائیں، نام میں لکھیں `.github/workflows/android-build.yml` اور `android-build.yml` فائل کا پورا مواد پیسٹ کرکے Commit کریں۔

## مرحلہ 4: Actions کھولیں اور APK بنوائیں
1. Repository میں اوپر **Actions** ٹیب دبائیں۔
2. **Android Build (Debug APK)** پر کلک کریں۔
3. اگر Build خود شروع نہیں ہوئی تو **Run workflow** → **Run workflow** دبائیں۔
4. 5 سے 10 منٹ انتظار کریں۔ پیلا گول نشان چل رہا ہو تو Build جاری ہے، سبز ✔ آ جائے تو مکمل۔

## مرحلہ 5: APK ڈاؤن لوڈ کریں
1. مکمل ہوئی Build پر کلک کریں۔
2. نیچے **Artifacts** میں **MultiTaskEarn-debug-apk** پر کلک کرکے ڈاؤن لوڈ کریں۔
3. یہ ZIP ہوگی۔ اسے Extract کریں، اندر `app-debug.apk` ملے گی۔

## مرحلہ 6: موبائل میں انسٹال کریں
1. `app-debug.apk` موبائل میں بھیجیں (USB، WhatsApp، Drive وغیرہ)۔
2. موبائل میں فائل کھولیں۔
3. اگر Android روکے تو **Settings** میں اس ایپ (File Manager / Chrome) کے لیے **Install unknown apps** کی اجازت دیں۔
4. **Install** دبائیں۔

## مرحلہ 7: Release APK اور Signing Key
`docs/SIGNING_GUIDE_UR.md` دیکھیں۔

## اگر Build میں خرابی آئے
Actions میں لال ✖ والی Build کھولیں، لال رنگ میں لکھی ہوئی خرابی کی لائنیں کاپی کرکے مجھے بھیجیں، میں درست کر دوں گا۔

## ویب سائٹ کا ایڈریس بدلنا
`app/src/main/java/com/multitaskearn/app/MainActivity.kt` میں `HOME_URL` اور `ALLOWED_HOSTS` بدلیں۔

## Android Studio میں کھولنا (اختیاری)
Android Studio میں **Open** کرکے پروجیکٹ فولڈر منتخب کریں۔ Gradle Sync مکمل ہونے دیں (انٹرنیٹ چاہیے)، پھر **Build → Build APK(s)**۔ اگر Gradle Wrapper کا پوچھے تو Gradle 8.7 استعمال کریں۔

## اہم باتیں
- ویب سائٹ `free.nf` مفت ہوسٹنگ پر ہے۔ ایسی ہوسٹنگ پر کبھی براؤزر چیک آتا ہے؛ ایپ میں پہلی بار صفحہ کھلنے میں تھوڑی دیر لگ سکتی ہے۔
- ایپ میں کوئی اشتہاری نیٹ ورک شامل نہیں۔
- اس ایپ کی APK میں خود Build یہاں ٹیسٹ نہیں ہو سکی؛ GitHub Actions میں پہلی Build ہی آپ کی تصدیق ہے۔
