# Release APK اور Signing Key (اردو)

**Keystore فائل اور پاس ورڈ کبھی GitHub Repository میں اپلوڈ نہ کریں۔** `.gitignore` میں `*.jks` پہلے سے موجود ہے۔

## 1) Keystore بنائیں (ایک ہی بار)
کمپیوٹر پر (JDK انسٹال ہو) Terminal / Command Prompt میں:

```
keytool -genkeypair -v -keystore multitaskearn.jks -alias multitaskearn -keyalg RSA -keysize 2048 -validity 10000
```
پاس ورڈ اور معلومات پوچھے گا۔ پاس ورڈ یاد رکھیں۔ **multitaskearn.jks کی بیک اپ کاپی محفوظ جگہ رکھیں**؛ کھو گئی تو ایپ کی اپڈیٹ اسی نام سے نہیں ہو سکے گی۔

## 2) Keystore کو Base64 ٹیکسٹ بنائیں
- Mac / Linux: `base64 -w 0 multitaskearn.jks` (Mac پر `base64 -i multitaskearn.jks`)
- Windows PowerShell:
```
[Convert]::ToBase64String([IO.File]::ReadAllBytes("multitaskearn.jks"))
```
جو لمبا ٹیکسٹ آئے وہ کاپی کریں۔

## 3) GitHub Secrets شامل کریں
Repository → **Settings** → **Secrets and variables** → **Actions** → **New repository secret**۔ یہ چار Secrets بنائیں:

| نام | قیمت |
|---|---|
| KEYSTORE_BASE64 | اوپر والا لمبا ٹیکسٹ |
| KEYSTORE_PASSWORD | Keystore کا پاس ورڈ |
| KEY_ALIAS | `multitaskearn` |
| KEY_PASSWORD | Key کا پاس ورڈ |

## 4) Release Build چلائیں
**Actions** → **Android Release (Signed APK)** → **Run workflow**۔ مکمل ہونے پر Artifacts سے **MultiTaskEarn-release-apk** ڈاؤن لوڈ کریں۔

## نوٹ
Google Play پر ڈالنا ہو تو بعد میں AAB (`bundleRelease`) درکار ہوگا، اور Play کی پالیسیاں آپ کی ایپ کے ماڈل پر لاگو ہوں گی۔ یہ پہلے الگ سے چیک کر لیں۔
